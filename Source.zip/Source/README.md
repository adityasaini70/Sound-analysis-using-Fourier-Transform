# Sound analysis using Fourier Transform

The material is part of **Signal and Systems** assignment, that I took in my 3rd semester at IIITD. 
